



import { create, all } from 'mathjs';
import { useCalculatorStore } from './store';

function App() {
  const {
    expression, setExpression,
    output, setOutput,
    variables, setVariables,
    varName, setVarName,
    varValue, setVarValue,
    history, setHistory
  } = useCalculatorStore();

  const math = create(all);
  const CONSTANTS = { pi: 3.1415, e: 2.7182 };

  // Evaluate the expression using mathjs
  const handleEvaluate = () => {
    let scope: Record<string, number> = { ...CONSTANTS };
    variables.forEach(v => {
      scope[v.name] = Number(v.value);
    });
    try {
      let expr = expression
        .replace(/sqrt\(/g, 'sqrt(')
        .replace(/sin\(/g, 'sin(')
        .replace(/cos\(/g, 'cos(')
        .replace(/tan\(/g, 'tan(')
        .replace(/\^/g, '^');
      expr = expr.replace(/\s+/g, '');
      const node = math.parse(expr);
      const val = node.evaluate(scope);
      if (typeof val === 'number' && !isNaN(val) && isFinite(val)) {
        setOutput(Number(val).toFixed(4));
        setHistory([{ expression, result: Number(val).toFixed(4) }, ...history]);
      } else {
        setOutput('Invalid result');
      }
    } catch (e: any) {
      setOutput('Error: ' + (e?.message || 'Invalid expression'));
    }
  };

  // Handle button click
  const handleButtonClick = (val: string) => {
    setExpression(expression + val);
  };

  // Handle variable add
  const handleAddVariable = () => {
    const name = varName.trim();
    if (!name || !/^[_a-zA-Z][_a-zA-Z0-9]*$/.test(name)) {
      setOutput('Invalid variable name');
      return;
    }
    if (Object.prototype.hasOwnProperty.call(CONSTANTS, name)) {
      setOutput('Cannot use constant name');
      return;
    }
    if (variables.some(v => v.name === name)) {
      setOutput('Variable already exists');
      return;
    }
    if (isNaN(Number(varValue))) {
      setOutput('Variable value must be a number');
      return;
    }
    setVariables([...variables, { name, value: varValue }]);
    setVarName('');
    setVarValue('');
    setOutput('');
  };

  // Handle history click
  const handleHistoryClick = (item: { expression: string; result: string }) => {
    setExpression(item.expression);
  };

  // Handle history delete
  const handleDeleteHistory = (idx: number) => {
    setHistory(history.filter((_, i) => i !== idx));
  };

  // Handle variable delete
  const handleDeleteVariable = (idx: number) => {
    setVariables(variables.filter((_, i) => i !== idx));
  };

  // Calculator buttons
  const buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '+', '(',
    ')', '^', 'sqrt(', 'sin(',
    'cos(', 'tan(', 'pi', 'e',
  ];

  return (
  <div className="fixed inset-0 flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-md p-4 rounded-xl bg-white shadow flex flex-col items-center">
        <h2 className="text-xl font-bold mb-3 text-gray-800">Calculator</h2>
        <div className="w-full flex gap-2 mb-3">
          <input
            className="flex-1 text-lg p-2 rounded border border-gray-300 bg-gray-50 text-gray-800 outline-none"
            type="text"
            value={expression}
            onChange={e => setExpression(e.target.value)}
            placeholder="0"
          />
          <button className="text-lg px-3 py-2 rounded bg-green-500 text-white hover:bg-green-600" onClick={handleEvaluate}>=</button>
        </div>
        <div className="w-full mb-3">
          <div className="min-h-[2rem] bg-gray-200 rounded px-2 py-1 text-right text-lg font-mono text-green-700">
            {output}
          </div>
        </div>
        <div className="w-full grid grid-cols-4 gap-2 mb-4">
          {buttons.map((b, i) => (
            <button key={i} className="text-lg py-2 rounded bg-gray-300 text-gray-800 hover:bg-gray-400" onClick={() => handleButtonClick(b)}>{b}</button>
          ))}
          <button className="col-span-2 py-2 rounded bg-red-400 text-white hover:bg-red-500" onClick={() => setExpression('')}>C</button>
          <button className="col-span-2 py-2 rounded bg-yellow-400 text-white hover:bg-yellow-500" onClick={() => setExpression(expression.slice(0, -1))}>⌫</button>
        </div>
        {/* Variables Section */}
        <div className="w-full mt-4 text-left">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Variables</h3>
          <div className="flex gap-2 mb-2 flex-wrap">
            <input
              className="p-1 rounded border border-gray-300 bg-gray-50 text-gray-800 flex-1 min-w-[80px]"
              type="text"
              value={varName}
              onChange={e => setVarName(e.target.value)}
              placeholder="Name"
            />
            <input
              className="p-1 rounded border border-gray-300 bg-gray-50 text-gray-800 flex-1 min-w-[80px]"
              type="text"
              value={varValue}
              onChange={e => setVarValue(e.target.value)}
              placeholder="Value"
            />
            <button className="px-3 rounded bg-green-700 text-white font-bold min-w-[48px]" onClick={handleAddVariable}>Add</button>
          </div>
          <ul className="mb-1">
            {variables.map((v, i) => (
              <li key={i} className="flex items-center gap-2 text-gray-800 mb-1">
                {v.name} = {v.value}
                <button className="bg-red-500 text-white rounded px-2 py-0.5 text-sm font-bold" onClick={() => handleDeleteVariable(i)}>x</button>
              </li>
            ))}
          </ul>
          <div className="text-sm text-gray-500">
            <strong>Constants:</strong> pi = 3.1415, e = 2.7182
          </div>
        </div>
        {/* History Section */}
        <div className="w-full mt-4 text-left">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">History</h3>
          <ul>
            {history.map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-gray-800 mb-1">
                <span className="underline cursor-pointer text-blue-500 hover:text-green-600" onClick={() => handleHistoryClick(item)}>
                  {item.expression} = {item.result}
                </span>
                <button className="bg-red-500 text-white rounded px-2 py-0.5 text-sm font-bold" onClick={() => handleDeleteHistory(i)}>x</button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;
