import { create } from 'zustand';

export type Variable = {
  name: string;
  value: string;
};

export type HistoryItem = {
  expression: string;
  result: string;
};

interface CalculatorState {
  expression: string;
  output: string;
  variables: Variable[];
  varName: string;
  varValue: string;
  history: HistoryItem[];
  setExpression: (v: string) => void;
  setOutput: (v: string) => void;
  setVariables: (v: Variable[]) => void;
  setVarName: (v: string) => void;
  setVarValue: (v: string) => void;
  setHistory: (v: HistoryItem[]) => void;
}

export const useCalculatorStore = create<CalculatorState>((set) => ({
  expression: '',
  output: '',
  variables: [],
  varName: '',
  varValue: '',
  history: [],
  setExpression: (expression) => set({ expression }),
  setOutput: (output) => set({ output }),
  setVariables: (variables) => set({ variables }),
  setVarName: (varName) => set({ varName }),
  setVarValue: (varValue) => set({ varValue }),
  setHistory: (history) => set({ history }),
}));
